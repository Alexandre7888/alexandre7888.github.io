#!/bin/bash

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${GREEN}     BOT SDK - Instalador${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo ""

# Verifica Node.js
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Instalando Node.js...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs -y
    echo -e "${GREEN}Node.js instalado!${NC}"
fi

# Cria diretório de componentes
mkdir -p components

# Dá permissão
chmod +x bot.js

echo -e "${GREEN}✅ Instalação concluída!${NC}"
echo -e "${CYAN}Para iniciar: node bot.js${NC}"