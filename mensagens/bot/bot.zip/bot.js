#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const https = require('https');
const readline = require('readline');
const { spawn } = require('child_process');

// Configuração do readline para setas
readline.emitKeypressEvents(process.stdin);
process.stdin.setRawMode(true);

const CONFIG = {
    firebaseUrl: 'https://html-785e3-default-rtdb.firebaseio.com',
    dataFile: 'bot_data.json',
    componentsDir: './components',
    activeFile: 'active_components.json'
};

let botConfig = null;
let serverProcess = null;
let isServerRunning = false;

const colors = {
    reset: '\x1b[0m', bright: '\x1b[1m', red: '\x1b[31m', green: '\x1b[32m',
    yellow: '\x1b[33m', blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m'
};

let selectedIndex = 0;

function clear() { console.clear(); }
function hideCursor() { process.stdout.write('\x1B[?25l'); }
function showCursor() { process.stdout.write('\x1B[?25h'); }

function header() {
    console.log(`${colors.blue}════════════════════════════════════════════════════════════════════${colors.reset}`);
    console.log(`${colors.magenta}${colors.bright}                    🤖 BOT SYSTEM - v2.0 🤖${colors.reset}`);
    console.log(`${colors.blue}════════════════════════════════════════════════════════════════════${colors.reset}`);
    console.log();
}

function drawMenu(items, title, showStatus = true) {
    clear();
    header();
    
    if (showStatus) {
        if (botConfig) {
            console.log(`${colors.green}✅ Bot: ${botConfig.userData?.name || botConfig.botId}${colors.reset}`);
            console.log(`${colors.green}💬 Grupos: ${Object.keys(botConfig.chats || {}).length}${colors.reset}`);
        } else {
            console.log(`${colors.red}❌ Bot: Não autenticado${colors.reset}`);
        }
        console.log(`${isServerRunning ? colors.green + '🟢 Servidor: ONLINE' : colors.red + '🔴 Servidor: OFFLINE'}${colors.reset}`);
        console.log();
    }
    
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│  ${title}${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    items.forEach((item, index) => {
        if (index === selectedIndex) {
            console.log(`${colors.green}${colors.bright}▶ ${item}${colors.reset}`);
        } else {
            console.log(`  ${item}`);
        }
    });
    
    console.log();
    console.log(`${colors.yellow}─────────────────────────────────────────────────────────────────${colors.reset}`);
    console.log(`${colors.cyan}↑/↓${colors.reset} navegar  ${colors.cyan}ENTER${colors.reset} selecionar  ${colors.cyan}ESC${colors.reset} voltar  ${colors.cyan}Q${colors.reset} sair`);
}

function httpsRequest(url, method = 'GET', data = null) {
    return new Promise((resolve, reject) => {
        const urlObj = new URL(url);
        const options = {
            hostname: urlObj.hostname,
            path: urlObj.pathname + urlObj.search,
            method: method,
            headers: { 'Content-Type': 'application/json' }
        };
        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => { 
                try { 
                    resolve(body ? JSON.parse(body) : null); 
                } catch(e) { 
                    resolve(body); 
                } 
            });
        });
        req.on('error', reject);
        if (data) req.write(JSON.stringify(data));
        req.end();
    });
}

// ==================== AUTENTICAÇÃO ====================
async function authBot() {
    clear();
    header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                         AUTENTICAÇÃO                           │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    return new Promise((resolve) => {
        const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl2.question(`${colors.yellow}📝 Digite o ID do Bot: ${colors.reset}`, async (botId) => {
            if (!botId) {
                console.log(`${colors.red}❌ ID não fornecido!${colors.reset}`);
                setTimeout(() => { rl2.close(); resolve(false); }, 2000);
                return;
            }
            
            console.log(`${colors.cyan}🔄 Buscando dados do bot...${colors.reset}`);
            
            try {
                // Busca dados do usuário/bot
                const userData = await httpsRequest(`${CONFIG.firebaseUrl}/users/${botId}.json`);
                
                if (!userData) {
                    console.log(`${colors.red}❌ Bot não encontrado! Verifique o ID.${colors.reset}`);
                    setTimeout(() => { rl2.close(); resolve(false); }, 2000);
                    return;
                }
                
                console.log(`${colors.cyan}🔄 Buscando grupos do bot...${colors.reset}`);
                
                // Busca todos os grupos que o bot participa
                const chats = {};
                
                if (userData.chats) {
                    for (const [chatId, chatData] of Object.entries(userData.chats)) {
                        try {
                            // Busca informações detalhadas do grupo
                            const groupData = await httpsRequest(`${CONFIG.firebaseUrl}/groups/${chatId}.json`);
                            
                            // Busca mensagens recentes para testar
                            const messages = await httpsRequest(`${CONFIG.firebaseUrl}/groups/${chatId}/messages.json`);
                            
                            chats[chatId] = {
                                id: chatId,
                                name: groupData?.name || chatData.name || chatId.substring(0, 15),
                                type: chatData.type || 'group',
                                memberCount: groupData?.members ? Object.keys(groupData.members).length : 0,
                                createdAt: chatData.timestamp,
                                lastMessage: messages ? Object.values(messages).sort((a,b) => b.timestamp - a.timestamp)[0] : null
                            };
                            
                            console.log(`${colors.green}  ✓ Encontrado: ${chats[chatId].name} (${chats[chatId].memberCount} membros)${colors.reset}`);
                        } catch(e) {
                            chats[chatId] = {
                                id: chatId,
                                name: chatData.name || chatId.substring(0, 15),
                                type: chatData.type || 'group',
                                memberCount: 0
                            };
                            console.log(`${colors.yellow}  ⚠️ ${chats[chatId].name}${colors.reset}`);
                        }
                    }
                }
                
                botConfig = {
                    botId: botId,
                    userData: userData,
                    chats: chats,
                    lastChecked: {},
                    ownerId: userData.ownerId,
                    username: userData.username,
                    name: userData.name,
                    createdAt: userData.createdAt
                };
                
                fs.writeFileSync(CONFIG.dataFile, JSON.stringify(botConfig, null, 2));
                
                console.log(`\n${colors.green}✅ Autenticado com sucesso!${colors.reset}`);
                console.log(`${colors.green}📛 Nome: ${userData.name || botId}${colors.reset}`);
                console.log(`${colors.green}💬 Grupos encontrados: ${Object.keys(chats).length}${colors.reset}`);
                
                rl2.close();
                
                // Volta para o menu principal após 2 segundos
                setTimeout(() => {
                    resolve(true);
                }, 3000);
                
            } catch (error) {
                console.log(`${colors.red}❌ Erro: ${error.message}${colors.reset}`);
                setTimeout(() => { rl2.close(); resolve(false); }, 2000);
            }
        });
    });
}

// ==================== ENVIO DE MENSAGEM ====================
async function sendTextMessage(chatId, text) {
    const timestamp = Date.now();
    const messageId = `msg_${timestamp}_${Math.random().toString(36).substr(2, 9)}`;
    
    const messageData = {
        ephemeral: false,
        senderId: botConfig.botId,
        senderName: botConfig.userData.name || 'Bot',
        text: text,
        timestamp: timestamp,
        type: 'text'
    };
    
    await httpsRequest(`${CONFIG.firebaseUrl}/groups/${chatId}/messages/${messageId}.json`, 'PUT', messageData);
    return true;
}

async function sendMediaMessage(chatId, type, fileData, caption = '') {
    const timestamp = Date.now();
    const messageId = `msg_${timestamp}_${Math.random().toString(36).substr(2, 9)}`;
    
    const messageData = {
        ephemeral: false,
        senderId: botConfig.botId,
        senderName: botConfig.userData.name || 'Bot',
        text: caption || (type === 'image' ? '📷 Imagem' : type === 'audio' ? '🎵 Áudio' : '📹 Vídeo'),
        fileData: fileData,
        timestamp: timestamp,
        type: type
    };
    
    if (type === 'image') messageData.fileName = 'image.jpg';
    if (type === 'audio') messageData.fileName = 'audio.webm';
    if (type === 'video') messageData.fileName = 'video.mp4';
    
    await httpsRequest(`${CONFIG.firebaseUrl}/groups/${chatId}/messages/${messageId}.json`, 'PUT', messageData);
    return true;
}

// Função para testar envio de mensagem
async function testSendMessage(chatId) {
    try {
        const testMsg = `🧪 Teste de conexão - Bot online! ${new Date().toLocaleTimeString()}`;
        await sendTextMessage(chatId, testMsg);
        return true;
    } catch(e) {
        return false;
    }
}

// ==================== SELECIONAR GRUPO E ENVIAR ====================
async function selectGroupAndSend() {
    if (!botConfig) {
        console.log(`${colors.red}❌ Autentique primeiro!${colors.reset}`);
        setTimeout(() => {}, 1500);
        return;
    }
    
    const groups = Object.values(botConfig.chats);
    
    if (groups.length === 0) {
        console.log(`${colors.red}❌ Nenhum grupo encontrado! O bot não está em nenhum grupo.${colors.reset}`);
        console.log(`${colors.yellow}⚠️ Adicione o bot a um grupo primeiro.${colors.reset}`);
        setTimeout(() => {}, 3000);
        return;
    }
    
    selectedIndex = 0;
    
    while (true) {
        const items = groups.map(g => `👥 ${g.name} (${g.memberCount} membros) - Tipo: ${g.type}`);
        drawMenu(items, '📋 SELECIONE O GRUPO PARA ENVIAR MENSAGEM', true);
        
        const key = await waitForKey();
        
        if (key.name === 'up') {
            selectedIndex = Math.max(0, selectedIndex - 1);
        } else if (key.name === 'down') {
            selectedIndex = Math.min(items.length - 1, selectedIndex + 1);
        } else if (key.name === 'return') {
            const selectedGroup = groups[selectedIndex];
            await sendMessageToGroup(selectedGroup);
            break;
        } else if (key.name === 'escape') {
            break;
        } else if (key.name === 'q') {
            process.exit(0);
        }
    }
}

async function sendMessageToGroup(group) {
    clear();
    header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│  ENVIAR MENSAGEM PARA: ${group.name}${colors.reset}`);
    console.log(`${colors.cyan}│  ID: ${group.id}${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    // Testa se consegue enviar mensagem
    console.log(`${colors.yellow}🔄 Testando conexão com o grupo...${colors.reset}`);
    const testResult = await testSendMessage(group.id);
    if (testResult) {
        console.log(`${colors.green}✅ Conexão OK! Mensagem de teste enviada!${colors.reset}`);
    } else {
        console.log(`${colors.red}❌ Falha na conexão! Verifique se o bot está no grupo.${colors.reset}`);
    }
    console.log();
    
    console.log(`${colors.yellow}📝 Tipos de mensagem:${colors.reset}`);
    console.log(`${colors.cyan}1.${colors.reset} Texto`);
    console.log(`${colors.cyan}2.${colors.reset} Áudio (Base64)`);
    console.log(`${colors.cyan}3.${colors.reset} Imagem (URL)`);
    console.log(`${colors.cyan}4.${colors.reset} Vídeo (URL)`);
    console.log();
    
    const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
    
    rl2.question(`${colors.yellow}👉 Tipo (1-4): ${colors.reset}`, async (type) => {
        if (type === '1') {
            rl2.question(`${colors.yellow}📝 Mensagem: ${colors.reset}`, async (msg) => {
                console.log(`${colors.cyan}🔄 Enviando...${colors.reset}`);
                await sendTextMessage(group.id, msg);
                console.log(`${colors.green}✅ Mensagem enviada para ${group.name}!${colors.reset}`);
                rl2.close();
                setTimeout(() => {}, 2000);
            });
        } else if (type === '2') {
            rl2.question(`${colors.yellow}📝 Áudio (Base64): ${colors.reset}`, async (data) => {
                console.log(`${colors.cyan}🔄 Enviando áudio...${colors.reset}`);
                await sendMediaMessage(group.id, 'audio', data);
                console.log(`${colors.green}✅ Áudio enviado para ${group.name}!${colors.reset}`);
                rl2.close();
                setTimeout(() => {}, 2000);
            });
        } else if (type === '3') {
            rl2.question(`${colors.yellow}📝 URL da imagem: ${colors.reset}`, async (url) => {
                rl2.question(`${colors.yellow}📝 Legenda (opcional): ${colors.reset}`, async (caption) => {
                    console.log(`${colors.cyan}🔄 Enviando imagem...${colors.reset}`);
                    await sendMediaMessage(group.id, 'image', url, caption);
                    console.log(`${colors.green}✅ Imagem enviada para ${group.name}!${colors.reset}`);
                    rl2.close();
                    setTimeout(() => {}, 2000);
                });
            });
        } else if (type === '4') {
            rl2.question(`${colors.yellow}📝 URL do vídeo: ${colors.reset}`, async (url) => {
                rl2.question(`${colors.yellow}📝 Legenda (opcional): ${colors.reset}`, async (caption) => {
                    console.log(`${colors.cyan}🔄 Enviando vídeo...${colors.reset}`);
                    await sendMediaMessage(group.id, 'video', url, caption);
                    console.log(`${colors.green}✅ Vídeo enviado para ${group.name}!${colors.reset}`);
                    rl2.close();
                    setTimeout(() => {}, 2000);
                });
            });
        } else {
            rl2.close();
        }
    });
}

// ==================== VER GRUPOS REAIS ====================
async function viewRealGroups() {
    if (!botConfig) {
        console.log(`${colors.red}❌ Autentique primeiro!${colors.reset}`);
        setTimeout(() => {}, 1500);
        return;
    }
    
    clear();
    header();
    
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                    GRUPOS QUE O BOT PARTICIPA                    │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    const groups = Object.values(botConfig.chats);
    
    if (groups.length === 0) {
        console.log(`${colors.yellow}⚠️ O bot não está em nenhum grupo ainda!${colors.reset}`);
        console.log();
        console.log(`${colors.cyan}💡 Como adicionar o bot a um grupo:${colors.reset}`);
        console.log(`  1. Use o link de convite do bot`);
        console.log(`  2. Ou adicione o ID do bot no grupo`);
    } else {
        console.log(`${colors.green}📋 Encontrados ${groups.length} grupo(s):${colors.reset}`);
        console.log();
        
        for (let i = 0; i < groups.length; i++) {
            const g = groups[i];
            console.log(`${colors.magenta}${i+1}. ${g.name}${colors.reset}`);
            console.log(`   ${colors.cyan}ID:${colors.reset} ${g.id}`);
            console.log(`   ${colors.cyan}Tipo:${colors.reset} ${g.type}`);
            console.log(`   ${colors.cyan}Membros:${colors.reset} ${g.memberCount}`);
            if (g.createdAt) {
                console.log(`   ${colors.cyan}Criado em:${colors.reset} ${new Date(g.createdAt).toLocaleString()}`);
            }
            console.log();
        }
    }
    
    console.log(`${colors.yellow}─────────────────────────────────────────────────────────────────${colors.reset}`);
    await new Promise(resolve => {
        const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl2.question(`${colors.cyan}Pressione ENTER para voltar${colors.reset}`, () => { rl2.close(); resolve(); });
    });
}

// ==================== SERVIDOR ====================
async function startServer() {
    if (isServerRunning) {
        console.log(`${colors.yellow}⚠️ Servidor já rodando!${colors.reset}`);
        setTimeout(() => {}, 1500);
        return;
    }
    if (!botConfig) {
        console.log(`${colors.red}❌ Autentique primeiro!${colors.reset}`);
        setTimeout(() => {}, 2000);
        return;
    }
    
    console.log(`${colors.green}🚀 Iniciando servidor do bot...${colors.reset}`);
    
    const serverScript = `
    const https = require('https');
    const fs = require('fs');
    const CONFIG = {
        firebaseUrl: '${CONFIG.firebaseUrl}',
        botData: ${JSON.stringify(botConfig)}
    };
    
    function httpsReq(url, method = 'GET', data = null) {
        return new Promise((resolve, reject) => {
            const u = new URL(url);
            const opt = { hostname: u.hostname, path: u.pathname + u.search, method, headers: { 'Content-Type': 'application/json' } };
            const req = https.request(opt, res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(b ? JSON.parse(b) : null); } catch(e) { resolve(b); } }); });
            req.on('error', reject);
            if (data) req.write(JSON.stringify(data));
            req.end();
        });
    }
    
    async function sendMessage(chatId, text, type = 'text', fileData = null) {
        const ts = Date.now();
        const mid = \`msg_\${ts}_\${Math.random().toString(36).substr(2,9)}\`;
        const data = {
            ephemeral: false,
            senderId: '${botConfig.botId}',
            senderName: '${botConfig.userData.name || 'Bot'}',
            text: text,
            timestamp: ts,
            type: type
        };
        if (fileData) data.fileData = fileData;
        await httpsReq(\`\${CONFIG.firebaseUrl}/groups/\${chatId}/messages/\${mid}.json\`, 'PUT', data);
    }
    
    async function checkMessages() {
        for (const [chatId, chatData] of Object.entries(CONFIG.botData.chats || {})) {
            try {
                const msgs = await httpsReq(\`\${CONFIG.firebaseUrl}/groups/\${chatId}/messages.json\`);
                if (msgs) {
                    const last = CONFIG.botData.lastChecked[chatId] || 0;
                    for (const [id, msg] of Object.entries(msgs)) {
                        if (msg.timestamp > last && msg.senderId !== '${botConfig.botId}') {
                            console.log(\`💬 [\${chatData.name}] \${msg.senderName}: \${msg.text || msg.type}\`);
                            
                            const send = (t, ty = 'text', fd = null) => sendMessage(chatId, t, ty, fd);
                            
                            const text = msg.text?.toLowerCase() || '';
                            if (text === 'oi' || text === 'olá') {
                                await send(\`Olá \${msg.senderName}! Como posso ajudar?\`);
                            }
                            if (text === '/hora') {
                                await send(\`🕐 \${new Date().toLocaleTimeString()}\`);
                            }
                            if (text === '/data') {
                                await send(\`📅 \${new Date().toLocaleDateString()}\`);
                            }
                            if (text === '/ping') {
                                await send('🏓 Pong! Bot online!');
                            }
                            if (text === '/grupos') {
                                const lista = Object.values(CONFIG.botData.chats).map(g => \`- \${g.name}\`).join('\\n');
                                await send(\`📋 Grupos que estou:\\n\${lista}\`);
                            }
                        }
                    }
                    CONFIG.botData.lastChecked[chatId] = Date.now();
                    fs.writeFileSync('${CONFIG.dataFile}', JSON.stringify(CONFIG.botData, null, 2));
                }
            } catch(e) {}
        }
    }
    
    setInterval(checkMessages, 5000);
    console.log('✅ Servidor rodando! Monitorando mensagens...');
    `;
    
    const tempFile = 'temp_server.js';
    fs.writeFileSync(tempFile, serverScript);
    serverProcess = spawn('node', [tempFile], { stdio: 'inherit' });
    isServerRunning = true;
    
    serverProcess.on('exit', () => {
        isServerRunning = false;
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    });
    
    console.log(`${colors.green}✅ Servidor iniciado!${colors.reset}`);
    setTimeout(() => {}, 1500);
}

function stopServer() {
    if (serverProcess) {
        serverProcess.kill();
        serverProcess = null;
        isServerRunning = false;
        console.log(`${colors.green}✅ Servidor parado!${colors.reset}`);
    } else {
        console.log(`${colors.yellow}⚠️ Nenhum servidor rodando${colors.reset}`);
    }
    setTimeout(() => {}, 1500);
}

// ==================== COMPONENTES ====================
function getActiveComponents() {
    try {
        if (fs.existsSync(CONFIG.activeFile)) {
            return JSON.parse(fs.readFileSync(CONFIG.activeFile, 'utf8')).components || [];
        }
    } catch(e) {}
    return [];
}

function saveActiveComponent(name) {
    let active = { components: [] };
    try {
        if (fs.existsSync(CONFIG.activeFile)) {
            active = JSON.parse(fs.readFileSync(CONFIG.activeFile, 'utf8'));
        }
    } catch(e) {}
    if (!active.components.includes(name)) active.components.push(name);
    fs.writeFileSync(CONFIG.activeFile, JSON.stringify(active, null, 2));
}

function removeActiveComponent(name) {
    try {
        if (fs.existsSync(CONFIG.activeFile)) {
            let active = JSON.parse(fs.readFileSync(CONFIG.activeFile, 'utf8'));
            active.components = active.components.filter(c => c !== name);
            fs.writeFileSync(CONFIG.activeFile, JSON.stringify(active, null, 2));
        }
    } catch(e) {}
}

async function manageComponents() {
    if (!fs.existsSync(CONFIG.componentsDir)) fs.mkdirSync(CONFIG.componentsDir, { recursive: true });
    
    while (true) {
        const files = fs.readdirSync(CONFIG.componentsDir).filter(f => f.endsWith('.js'));
        const active = getActiveComponents();
        
        const items = files.map(f => {
            const status = active.includes(f) ? `${colors.green}[●]${colors.reset}` : `${colors.red}[○]${colors.reset}`;
            return `${status} ${f}`;
        });
        items.push('─── Criar novo componente ───');
        items.push('─── Voltar ───');
        
        drawMenu(items, '📦 GERENCIAR COMPONENTES', true);
        
        const key = await waitForKey();
        
        if (key.name === 'up') {
            selectedIndex = Math.max(0, selectedIndex - 1);
        } else if (key.name === 'down') {
            selectedIndex = Math.min(items.length - 1, selectedIndex + 1);
        } else if (key.name === 'return') {
            if (selectedIndex === items.length - 1) {
                break;
            } else if (selectedIndex === items.length - 2) {
                await createComponent();
            } else if (selectedIndex < files.length) {
                const selectedFile = files[selectedIndex];
                if (active.includes(selectedFile)) {
                    removeActiveComponent(selectedFile);
                    console.log(`${colors.yellow}⚠️ Desativado: ${selectedFile}${colors.reset}`);
                } else {
                    saveActiveComponent(selectedFile);
                    console.log(`${colors.green}✅ Ativado: ${selectedFile}${colors.reset}`);
                }
                setTimeout(() => {}, 1000);
            }
        } else if (key.name === 'escape') {
            break;
        } else if (key.name === 'q') {
            process.exit(0);
        }
    }
}

async function createComponent() {
    clear();
    header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                     CRIAR COMPONENTE                          │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    console.log(`${colors.yellow}📝 Template do componente:${colors.reset}`);
    console.log(`${colors.green}module.exports = {`);
    console.log(`  name: "Meu Componente",`);
    console.log(`  onMessage: async (msg, send) => {`);
    console.log(`    if (msg.text === "oi") await send("Olá!");`);
    console.log(`  }`);
    console.log(`};${colors.reset}`);
    console.log();
    
    const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl2.question(`${colors.yellow}📝 Nome do arquivo (ex: meu_componente.js): ${colors.reset}`, (filename) => {
        if (!filename.endsWith('.js')) filename += '.js';
        
        console.log(`${colors.cyan}📝 Digite o código (digite 'FIM' para finalizar):${colors.reset}`);
        let codeLines = [];
        
        const promptCode = () => {
            rl2.question('', (line) => {
                if (line.trim() === 'FIM') {
                    const code = codeLines.join('\n');
                    if (code.trim()) {
                        const filepath = path.join(CONFIG.componentsDir, filename);
                        fs.writeFileSync(filepath, code);
                        console.log(`${colors.green}✅ Componente criado: ${filename}${colors.reset}`);
                    } else {
                        console.log(`${colors.red}❌ Código vazio!${colors.reset}`);
                    }
                    rl2.close();
                    setTimeout(() => {}, 2000);
                } else {
                    codeLines.push(line);
                    promptCode();
                }
            });
        };
        promptCode();
    });
}

// ==================== STATUS ====================
async function showStatus() {
    clear();
    header();
    if (botConfig) {
        console.log(`${colors.green}✅ BOT AUTENTICADO${colors.reset}`);
        console.log(`${colors.cyan}ID:${colors.reset} ${botConfig.botId}`);
        console.log(`${colors.cyan}Nome:${colors.reset} ${botConfig.userData.name || 'N/A'}`);
        console.log(`${colors.cyan}Username:${colors.reset} ${botConfig.username || 'N/A'}`);
        console.log(`${colors.cyan}Dono:${colors.reset} ${botConfig.ownerId || 'N/A'}`);
        console.log(`${colors.cyan}Criado:${colors.reset} ${new Date(botConfig.createdAt).toLocaleString()}`);
        console.log(`${colors.cyan}Grupos:${colors.reset} ${Object.keys(botConfig.chats).length}`);
        console.log(`\n${colors.magenta}📦 Componentes ativos:${colors.reset}`);
        const active = getActiveComponents();
        if (active.length === 0) console.log(`  ${colors.yellow}Nenhum${colors.reset}`);
        else active.forEach(c => console.log(`  ${colors.green}✓${colors.reset} ${c}`));
        console.log(`\n${colors.magenta}🖥️ Servidor:${colors.reset} ${isServerRunning ? `${colors.green}ONLINE` : `${colors.red}OFFLINE`}`);
        
        console.log(`\n${colors.magenta}👥 Grupos do bot:${colors.reset}`);
        Object.values(botConfig.chats).forEach((g) => {
            console.log(`  ${colors.cyan}📌${colors.reset} ${g.name} - ${g.memberCount} membros`);
        });
    } else {
        console.log(`${colors.red}❌ BOT NÃO AUTENTICADO${colors.reset}`);
    }
    console.log(`\n${colors.yellow}Pressione ENTER para voltar${colors.reset}`);
    await new Promise(resolve => {
        const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl2.question('', () => { rl2.close(); resolve(); });
    });
}

// ==================== FUNÇÃO DE ESPERA DE TECLA ====================
function waitForKey() {
    return new Promise((resolve) => {
        const onKey = (str, key) => {
            process.stdin.removeListener('keypress', onKey);
            resolve(key);
        };
        process.stdin.on('keypress', onKey);
    });
}

// ==================== MENU PRINCIPAL ====================
async function main() {
    hideCursor();
    
    const menuItems = [
        '🔐 Autenticar Bot',
        '🚀 Iniciar Servidor',
        '⏹️  Parar Servidor',
        '📨 Enviar Mensagem',
        '👥 Ver Grupos do Bot',
        '📦 Gerenciar Componentes',
        'ℹ️  Status',
        '🚪 Sair'
    ];
    
    selectedIndex = 0;
    
    while (true) {
        drawMenu(menuItems, 'MENU PRINCIPAL', true);
        
        const key = await waitForKey();
        
        if (key.name === 'up') {
            selectedIndex = Math.max(0, selectedIndex - 1);
        } else if (key.name === 'down') {
            selectedIndex = Math.min(menuItems.length - 1, selectedIndex + 1);
        } else if (key.name === 'return') {
            const option = selectedIndex;
            
            if (option === 0) {
                await authBot();
                // Após autenticar, volta ao menu principal já autenticado
            }
            else if (option === 1) await startServer();
            else if (option === 2) stopServer();
            else if (option === 3) await selectGroupAndSend();
            else if (option === 4) await viewRealGroups();
            else if (option === 5) await manageComponents();
            else if (option === 6) await showStatus();
            else if (option === 7) {
                if (serverProcess) serverProcess.kill();
                showCursor();
                clear();
                console.log(`${colors.green}👋 Até logo!${colors.reset}`);
                process.exit(0);
            }
        } else if (key.name === 'q') {
            if (serverProcess) serverProcess.kill();
            showCursor();
            clear();
            console.log(`${colors.green}👋 Até logo!${colors.reset}`);
            process.exit(0);
        }
    }
}

// Inicia o programa
console.log(`${colors.green}🚀 Iniciando BOT SYSTEM...${colors.reset}`);
console.log(`${colors.cyan}Use as setas ↑/↓ para navegar e ENTER para selecionar${colors.reset}`);
console.log();
main();