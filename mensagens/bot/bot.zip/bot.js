#!/usr/bin/env node

const firebase = require('firebase');
const chalk = require('chalk');
const figlet = require('figlet');
const inquirer = require('inquirer');
const fs = require('fs');
const path = require('path');

// ============================================
// CONFIGURAÇÃO FIREBASE
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBzRLpZJDMeFASIjje4SJBfTInIEO-GKVI",
  databaseURL: "https://html-785e3-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ============================================
// CLASSE PRINCIPAL DO BOT
// ============================================
class BotTerminal {
  constructor() {
    this.bots = [];
    this.botAtivo = null;
    this.grupoAtivo = null;
    this.executando = false;
    this.componentes = [];
    this.stats = {
      mensagensEnviadas: 0,
      mensagensRecebidas: 0,
      uptime: Date.now()
    };
  }

  async iniciar() {
    console.clear();
    
    console.log(chalk.cyan(figlet.textSync('BOT SYSTEM', {
      font: 'Standard',
      horizontalLayout: 'default',
      verticalLayout: 'default'
    })));

    console.log(chalk.green('╔══════════════════════════════════════════════════════════╗'));
    console.log(chalk.green('║              🤖 BOT SYSTEM - SIMPLES                     ║'));
    console.log(chalk.green('║          Mensagens • Grupos • Componentes                ║'));
    console.log(chalk.green('╚══════════════════════════════════════════════════════════╝'));
    
    await this.carregarDados();
    await this.verificarConexao();
    await this.menuPrincipal();
  }

  async carregarDados() {
    const dataPath = path.join(__dirname, 'dados.json');
    
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      this.bots = data.bots || [];
      this.componentes = data.componentes || [];
      console.log(chalk.yellow(`📦 ${this.bots.length} bots carregados`));
    }
    
    // Carregar componentes da pasta
    const compPath = path.join(__dirname, 'componentes');
    if (fs.existsSync(compPath)) {
      const arquivos = fs.readdirSync(compPath).filter(f => f.endsWith('.js'));
      for (const arquivo of arquivos) {
        try {
          const comp = require(path.join(compPath, arquivo));
          this.componentes.push(comp);
          console.log(chalk.green(`✅ Componente carregado: ${comp.nome || arquivo}`));
        } catch(e) {
          console.log(chalk.red(`❌ Erro ao carregar ${arquivo}: ${e.message}`));
        }
      }
    }
  }

  salvarDados() {
    const data = {
      bots: this.bots,
      componentes: this.componentes
    };
    
    fs.writeFileSync(path.join(__dirname, 'dados.json'), JSON.stringify(data, null, 2));
    console.log(chalk.green('💾 Dados salvos'));
  }

  async verificarConexao() {
    try {
      const connectedRef = db.ref('.info/connected');
      connectedRef.on('value', (snap) => {
        if (snap.val() === true) {
          console.log(chalk.green('✅ Conectado ao Firebase'));
        } else {
          console.log(chalk.red('❌ Desconectado do Firebase'));
        }
      });
    } catch (error) {}
  }

  async menuPrincipal() {
    while (true) {
      const { opcao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcao',
          message: chalk.cyan('🤖 Menu Principal:'),
          choices: [
            { name: '📊 Dashboard', value: 'dashboard' },
            { name: '🤖 Gerenciar Bots', value: 'bots' },
            { name: '👥 Gerenciar Grupos', value: 'grupos' },
            { name: '🧩 Gerenciar Componentes', value: 'componentes' },
            { name: '💬 Enviar Mensagem', value: 'enviar' },
            { name: '👀 Monitorar Mensagens', value: 'monitorar' },
            { name: '🚀 Iniciar 24/7', value: 'iniciar' },
            { name: '🛑 Parar', value: 'parar' },
            new inquirer.Separator(),
            { name: '🚪 Sair', value: 'sair' }
          ]
        }
      ]);

      if (opcao === 'sair') {
        await this.parar();
        console.log(chalk.yellow('👋 Até logo!'));
        process.exit(0);
      }

      await this.executarOpcao(opcao);
    }
  }

  async executarOpcao(opcao) {
    const handlers = {
      'dashboard': () => this.mostrarDashboard(),
      'bots': () => this.gerenciarBots(),
      'grupos': () => this.gerenciarGrupos(),
      'componentes': () => this.gerenciarComponentes(),
      'enviar': () => this.enviarMensagem(),
      'monitorar': () => this.monitorarMensagens(),
      'iniciar': () => this.iniciar24h(),
      'parar': () => this.parar()
    };

    if (handlers[opcao]) {
      await handlers[opcao]();
    }
  }

  async mostrarDashboard() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 DASHBOARD\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    const status = this.executando ? chalk.green('✅ ATIVO') : chalk.yellow('⭕ INATIVO');
    console.log(`${chalk.white('Status:')} ${status}`);
    console.log(`${chalk.white('Bot:')} ${this.botAtivo ? chalk.cyan(this.botAtivo.nome) : chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Grupo:')} ${this.grupoAtivo || chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Bots:')} ${chalk.yellow(this.bots.length)}`);
    console.log(`${chalk.white('Componentes:')} ${chalk.yellow(this.componentes.length)}`);
    console.log(`${chalk.white('Mensagens Enviadas:')} ${chalk.green(this.stats.mensagensEnviadas)}`);
    console.log(`${chalk.white('Mensagens Recebidas:')} ${chalk.green(this.stats.mensagensRecebidas)}`);
    
    console.log(chalk.white('\n═'.repeat(50)));
    await this.pausa();
  }

  async gerenciarBots() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n🤖 GERENCIAR BOTS\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha:',
          choices: [
            { name: '➕ Criar Bot', value: 'criar' },
            { name: '📋 Listar Bots', value: 'listar' },
            { name: '✅ Selecionar Bot', value: 'selecionar' },
            { name: '🗑️ Deletar Bot', value: 'deletar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'criar': await this.criarBot(); break;
        case 'listar': await this.listarBots(); break;
        case 'selecionar': await this.selecionarBot(); break;
        case 'deletar': await this.deletarBot(); break;
      }
    }
  }

  async criarBot() {
    const respostas = await inquirer.prompt([
      { type: 'input', name: 'nome', message: 'Nome do bot:' },
      { type: 'input', name: 'avatar', message: 'URL do avatar:', default: 'https://i.imgur.com/2Vq5pZm.png' }
    ]);

    const id = `bot_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    this.bots.push({
      id,
      nome: respostas.nome,
      avatar: respostas.avatar,
      criadoEm: Date.now(),
      grupos: []
    });

    this.salvarDados();
    await db.ref(`users/${id}`).set({ id, nome: respostas.nome, avatar: respostas.avatar });
    console.log(chalk.green(`\n✅ Bot "${respostas.nome}" criado!`));
    await this.pausa();
  }

  async listarBots() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 BOTS\n'));
    
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot cadastrado.'));
    } else {
      this.bots.forEach((bot, i) => {
        const ativo = this.botAtivo?.id === bot.id ? chalk.green(' [ATIVO]') : '';
        console.log(chalk.white(`${i + 1}. ${bot.nome}${ativo}`));
      });
    }
    
    await this.pausa();
  }

  async selecionarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot cadastrado.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione um bot:',
        choices: this.bots.map(b => ({ name: b.nome, value: b.id }))
      }
    ]);

    this.botAtivo = this.bots.find(b => b.id === botId);
    console.log(chalk.green(`\n✅ Bot "${this.botAtivo.nome}" selecionado!`));
    await this.pausa();
  }

  async deletarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot para deletar.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione para deletar:',
        choices: this.bots.map(b => ({ name: b.nome, value: b.id }))
      }
    ]);

    const { confirmar } = await inquirer.prompt([
      { type: 'confirm', name: 'confirmar', message: 'Tem certeza?', default: false }
    ]);

    if (confirmar) {
      this.bots = this.bots.filter(b => b.id !== botId);
      if (this.botAtivo?.id === botId) this.botAtivo = null;
      this.salvarDados();
      await db.ref(`users/${botId}`).remove();
      console.log(chalk.green('✅ Bot deletado!'));
    }
    
    await this.pausa();
  }

  async gerenciarGrupos() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n👥 GERENCIAR GRUPOS\n'));
      console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.nome)}`));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha:',
          choices: [
            { name: '➕ Entrar em Grupo', value: 'entrar' },
            { name: '📋 Listar Grupos', value: 'listar' },
            { name: '✅ Selecionar Grupo', value: 'selecionar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'entrar': await this.entrarGrupo(); break;
        case 'listar': await this.listarGrupos(); break;
        case 'selecionar': await this.selecionarGrupo(); break;
      }
    }
  }

  async entrarGrupo() {
    const { grupoId } = await inquirer.prompt([
      { type: 'input', name: 'grupoId', message: 'ID do grupo:' }
    ]);

    await db.ref(`groups/${grupoId}/members/${this.botAtivo.id}`).set({
      id: this.botAtivo.id,
      nome: this.botAtivo.nome,
      role: 'member',
      joinedAt: Date.now()
    });

    if (!this.botAtivo.grupos) this.botAtivo.grupos = [];
    if (!this.botAtivo.grupos.includes(grupoId)) {
      this.botAtivo.grupos.push(grupoId);
    }

    this.grupoAtivo = grupoId;
    this.salvarDados();

    console.log(chalk.green(`\n✅ Entrou no grupo ${grupoId}!`));
    await this.pausa();
  }

  async listarGrupos() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 GRUPOS\n'));
    
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Nenhum grupo.'));
    } else {
      for (const grupoId of this.botAtivo.grupos) {
        try {
          const snap = await db.ref(`groups/${grupoId}`).once('value');
          const grupo = snap.val();
          const nome = grupo?.nome || grupoId;
          const ativo = this.grupoAtivo === grupoId ? chalk.green(' [ATIVO]') : '';
          console.log(chalk.white(`📌 ${nome}${ativo}`));
        } catch(e) {
          console.log(chalk.white(`📌 ${grupoId}`));
        }
      }
    }
    
    await this.pausa();
  }

  async selecionarGrupo() {
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Nenhum grupo.'));
      await this.pausa();
      return;
    }

    const opcoes = [];
    for (const grupoId of this.botAtivo.grupos) {
      try {
        const snap = await db.ref(`groups/${grupoId}`).once('value');
        const grupo = snap.val();
        opcoes.push({ name: grupo?.nome || grupoId, value: grupoId });
      } catch(e) {
        opcoes.push({ name: grupoId, value: grupoId });
      }
    }

    const { grupoId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'grupoId',
        message: 'Selecione um grupo:',
        choices: opcoes
      }
    ]);

    this.grupoAtivo = grupoId;
    console.log(chalk.green(`\n✅ Grupo selecionado!`));
    await this.pausa();
  }

  async gerenciarComponentes() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n🧩 GERENCIAR COMPONENTES\n'));
      console.log(chalk.gray('Componentes são scripts que respondem automaticamente'));
      console.log(chalk.gray('às mensagens recebidas.\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha:',
          choices: [
            { name: '📝 Criar Componente', value: 'criar' },
            { name: '📋 Listar Componentes', value: 'listar' },
            { name: '🧪 Testar Componente', value: 'testar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'criar': await this.criarComponente(); break;
        case 'listar': await this.listarComponentes(); break;
        case 'testar': await this.testarComponente(); break;
      }
    }
  }

  async criarComponente() {
    const { nome } = await inquirer.prompt([
      { type: 'input', name: 'nome', message: 'Nome do componente:' }
    ]);

    const { descricao } = await inquirer.prompt([
      { type: 'input', name: 'descricao', message: 'Descrição:' }
    ]);

    const { codigo } = await inquirer.prompt([
      { type: 'editor', name: 'codigo', message: 'Digite o código do componente:' }
    ]);

    const id = `comp_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    const componente = {
      id,
      nome,
      descricao,
      codigo,
      criadoEm: Date.now()
    };

    this.componentes.push(componente);
    this.salvarDados();

    console.log(chalk.green(`\n✅ Componente "${nome}" criado!`));
    await this.pausa();
  }

  async listarComponentes() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 COMPONENTES\n'));
    
    if (this.componentes.length === 0) {
      console.log(chalk.yellow('Nenhum componente criado.'));
    } else {
      this.componentes.forEach((comp, i) => {
        console.log(chalk.white(`${i + 1}. ${chalk.cyan(comp.nome)}`));
        console.log(chalk.gray(`   ${comp.descricao}`));
      });
    }
    
    await this.pausa();
  }

  async testarComponente() {
    if (this.componentes.length === 0) {
      console.log(chalk.yellow('Nenhum componente para testar.'));
      await this.pausa();
      return;
    }

    const { compId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'compId',
        message: 'Selecione um componente:',
        choices: this.componentes.map(c => ({ name: c.nome, value: c.id }))
      }
    ]);

    const componente = this.componentes.find(c => c.id === compId);
    
    const { mensagem } = await inquirer.prompt([
      { type: 'input', name: 'mensagem', message: 'Mensagem de teste:' }
    ]);

    console.log(chalk.yellow('\n🔄 Executando componente...\n'));
    
    try {
      const send = (texto) => {
        console.log(chalk.green(`📤 Resposta: ${texto}`));
      };
      
      const msg = {
        text: mensagem,
        senderId: 'teste',
        senderName: 'Teste'
      };
      
      const func = new Function('msg', 'send', componente.codigo);
      await func(msg, send);
      
      console.log(chalk.green('\n✅ Componente executado com sucesso!'));
    } catch (error) {
      console.log(chalk.red(`\n❌ Erro: ${error.message}`));
    }
    
    await this.pausa();
  }

  async enviarMensagem() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro.'));
      await this.pausa();
      return;
    }

    const { mensagem } = await inquirer.prompt([
      { type: 'input', name: 'mensagem', message: 'Mensagem:' }
    ]);

    await this.enviarMensagemServidor(mensagem);
    console.log(chalk.green(`\n✅ Mensagem enviada!`));
    await this.pausa();
  }

  async enviarMensagemServidor(texto) {
    const timestamp = Date.now();
    const hora = new Date(timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    await db.ref(`groups/${this.grupoAtivo}/messages`).push({
      senderId: this.botAtivo.id,
      senderName: this.botAtivo.nome,
      text: texto,
      timestamp: timestamp,
      time: hora
    });
    
    this.stats.mensagensEnviadas++;
  }

  async monitorarMensagens() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro.'));
      await this.pausa();
      return;
    }

    console.clear();
    console.log(chalk.cyan.bold('\n👀 MONITORANDO MENSAGENS\n'));
    console.log(chalk.yellow('Pressione CTRL+C para parar\n'));
    console.log(chalk.white('═'.repeat(50)));

    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    const onMessage = (snapshot) => {
      const msg = snapshot.val();
      if (msg.senderId === this.botAtivo.id) return;
      
      console.log(chalk.gray(`[${msg.time}]`), chalk.cyan(msg.senderName + ':'), chalk.white(msg.text));
      this.stats.mensagensRecebidas++;
      
      // Executar componentes automaticamente
      this.executarComponentes(msg);
    };

    messagesRef.limitToLast(1).on('child_added', onMessage);

    await new Promise(resolve => {
      const handler = () => {
        messagesRef.off('child_added', onMessage);
        console.log(chalk.yellow('\n\n👋 Monitoramento encerrado.'));
        resolve();
      };
      process.on('SIGINT', handler);
    });
  }

  async executarComponentes(msg) {
    if (!msg.text) return;

    const send = async (texto) => {
      await this.enviarMensagemServidor(texto);
    };

    for (const comp of this.componentes) {
      try {
        const func = new Function('msg', 'send', comp.codigo);
        await func(msg, send);
      } catch (error) {
        console.log(chalk.red(`❌ Erro no componente ${comp.nome}: ${error.message}`));
      }
    }
  }

  async iniciar24h() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro.'));
      await this.pausa();
      return;
    }

    this.executando = true;
    console.clear();
    console.log(chalk.green.bold('\n🚀 BOT INICIADO 24/7\n'));
    console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.nome)}`));
    console.log(chalk.white(`Grupo: ${chalk.cyan(this.grupoAtivo)}`));

    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    const onMessage = (snapshot) => {
      const msg = snapshot.val();
      if (msg.senderId !== this.botAtivo.id) {
        this.executarComponentes(msg);
        this.stats.mensagensRecebidas++;
      }
    };

    messagesRef.on('child_added', onMessage);

    console.log(chalk.gray('\n✅ Bot rodando 24/7!'));
    console.log(chalk.gray('Pressione qualquer tecla para voltar...'));
    await this.pausa();
  }

  async parar() {
    if (!this.executando) return;
    this.executando = false;
    if (this.grupoAtivo) {
      db.ref(`groups/${this.grupoAtivo}/messages`).off();
    }
    console.log(chalk.yellow('\n🛑 Bot parado.'));
    await this.pausa();
  }

  async pausa() {
    await inquirer.prompt([{ type: 'input', name: 'c', message: chalk.gray('\nPressione ENTER...') }]);
  }
}

// Iniciar
const bot = new BotTerminal();
bot.iniciar().catch(console.error);