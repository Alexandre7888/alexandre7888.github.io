#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const https = require('https');
const readline = require('readline');
const { spawn } = require('child_process');

const CONFIG = {
    firebaseUrl: 'https://html-785e3-default-rtdb.firebaseio.com',
    dataFile: 'bot_data.json',
    rolesFile: 'roles.json',
    componentsDir: './components',
    activeFile: 'active_components.json'
};

let botConfig = null;
let serverProcess = null;
let isServerRunning = false;

const colors = {
    reset: '\x1b[0m', bright: '\x1b[1m', red: '\x1b[31m', green: '\x1b[32m',
    yellow: '\x1b[33m', blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m'
};

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function clear() { console.clear(); }
function header() {
    console.log(`${colors.blue}════════════════════════════════════════════════════════════════════${colors.reset}`);
    console.log(`${colors.magenta}${colors.bright}                    🤖 BOT SYSTEM - COMPLETO 🤖${colors.reset}`);
    console.log(`${colors.blue}════════════════════════════════════════════════════════════════════${colors.reset}`);
    console.log();
}

function httpsRequest(url, method = 'GET', data = null) {
    return new Promise((resolve, reject) => {
        const urlObj = new URL(url);
        const options = {
            hostname: urlObj.hostname,
            path: urlObj.pathname + urlObj.search,
            method: method,
            headers: { 'Content-Type': 'application/json' }
        };
        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => { try { resolve(body ? JSON.parse(body) : null); } catch(e) { resolve(body); } });
        });
        req.on('error', reject);
        if (data) req.write(JSON.stringify(data));
        req.end();
    });
}

// ==================== AUTENTICAÇÃO ====================
async function authBot() {
    clear(); header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                         AUTENTICAÇÃO                           │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    return new Promise((resolve) => {
        rl.question(`${colors.yellow}📝 Digite o ID do Bot: ${colors.reset}`, async (botId) => {
            if (!botId) {
                console.log(`${colors.red}❌ ID não fornecido!${colors.reset}`);
                setTimeout(() => resolve(false), 2000);
                return;
            }
            
            console.log(`${colors.cyan}🔄 Autenticando...${colors.reset}`);
            
            try {
                // Busca dados do usuário/bot no Firebase
                const userData = await httpsRequest(`${CONFIG.firebaseUrl}/users/${botId}.json`);
                
                if (!userData) {
                    console.log(`${colors.red}❌ Bot não encontrado! Verifique o ID.${colors.reset}`);
                    setTimeout(() => resolve(false), 2000);
                    return;
                }
                
                // Carrega chats e comunidades
                const chats = {};
                const communities = {};
                
                if (userData.chats) {
                    for (const [chatId, chatData] of Object.entries(userData.chats)) {
                        chats[chatId] = chatData;
                    }
                }
                
                if (userData.communities) {
                    for (const [commId, commData] of Object.entries(userData.communities)) {
                        communities[commId] = commData;
                    }
                }
                
                botConfig = {
                    botId: botId,
                    userData: userData,
                    chats: chats,
                    communities: communities,
                    lastChecked: {},
                    token: userData.token || null,
                    inviteToken: userData.inviteToken || null,
                    createdAt: userData.createdAt,
                    ownerId: userData.ownerId,
                    username: userData.username,
                    name: userData.name,
                    description: userData.description || '',
                    isBot: userData.isBot || true
                };
                
                fs.writeFileSync(CONFIG.dataFile, JSON.stringify(botConfig, null, 2));
                
                console.log(`${colors.green}✅ Bot autenticado com sucesso!${colors.reset}`);
                console.log(`${colors.green}📛 Nome: ${userData.name || botId}${colors.reset}`);
                console.log(`${colors.green}👤 Dono: ${userData.ownerId || 'N/A'}${colors.reset}`);
                console.log(`${colors.green}💬 Chats disponíveis: ${Object.keys(chats).length}${colors.reset}`);
                console.log(`${colors.green}👥 Comunidades: ${Object.keys(communities).length}${colors.reset}`);
                
                // Carrega cargos salvos
                if (fs.existsSync(CONFIG.rolesFile)) {
                    const savedRoles = JSON.parse(fs.readFileSync(CONFIG.rolesFile, 'utf8'));
                    botConfig.roles = savedRoles;
                }
                
                setTimeout(() => resolve(true), 2000);
            } catch (error) {
                console.log(`${colors.red}❌ Erro: ${error.message}${colors.reset}`);
                setTimeout(() => resolve(false), 2000);
            }
        });
    });
}

// ==================== SISTEMA DE CARGOS E PERMISSÕES ====================
function loadRoles(chatId) {
    try {
        const rolesFile = `roles_${chatId}.json`;
        if (fs.existsSync(rolesFile)) {
            return JSON.parse(fs.readFileSync(rolesFile, 'utf8'));
        }
    } catch (error) {}
    return { cargos_personalizados: {}, dono: botConfig?.ownerId || null };
}

function saveRoles(chatId, roles) {
    try {
        const rolesFile = `roles_${chatId}.json`;
        fs.writeFileSync(rolesFile, JSON.stringify(roles, null, 2));
        return true;
    } catch (error) { return false; }
}

function hasPermission(chatId, memberId, permission) {
    const roles = loadRoles(chatId);
    
    // Dono tem todas as permissões
    if (roles.dono === memberId) return true;
    
    // Verifica em todos os cargos do membro
    for (const [roleName, roleData] of Object.entries(roles.cargos_personalizados || {})) {
        if (roleData.membros && roleData.membros.includes(memberId)) {
            if (roleData.permissoes && roleData.permissoes.includes(permission)) {
                return true;
            }
        }
    }
    return false;
}

async function createRole(chatId) {
    clear(); header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                       CRIAR CARGO                              │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    const roles = loadRoles(chatId);
    
    rl.question(`${colors.yellow}📝 Nome do cargo: ${colors.reset}`, (roleName) => {
        if (!roleName) {
            console.log(`${colors.red}❌ Nome inválido!${colors.reset}`);
            setTimeout(() => {}, 1500);
            return;
        }
        
        rl.question(`${colors.yellow}🎨 Cor do cargo (ex: #FF0000): ${colors.reset}`, (color) => {
            rl.question(`${colors.yellow}👥 Membros (IDs separados por vírgula): ${colors.reset}`, (membros) => {
                console.log(`${colors.yellow}🔧 Permissões disponíveis:${colors.reset}`);
                const permissoes = [
                    "enviar_mensagem", "enviar_foto", "enviar_audio", "enviar_documento",
                    "enviar_link", "responder_mensagem", "reagir_mensagem", "apagar_propria_mensagem",
                    "fixar_mensagem", "mutar_membro", "remover_membro", "adicionar_membro",
                    "criar_enquete", "votar_enquete", "gerenciar_cargos"
                ];
                
                permissoes.forEach((p, i) => {
                    console.log(`${colors.cyan}${i+1}.${colors.reset} ${p}`);
                });
                console.log();
                
                rl.question(`${colors.yellow}📝 Permissões (números separados por vírgula): ${colors.reset}`, (permsInput) => {
                    const selectedPerms = [];
                    const nums = permsInput.split(',').map(n => parseInt(n.trim()));
                    nums.forEach(n => {
                        if (n >= 1 && n <= permissoes.length) {
                            selectedPerms.push(permissoes[n-1]);
                        }
                    });
                    
                    roles.cargos_personalizados[roleName] = {
                        cor: color || "#FFFFFF",
                        membros: membros ? membros.split(',').map(m => m.trim()) : [],
                        permissoes: selectedPerms
                    };
                    
                    saveRoles(chatId, roles);
                    console.log(`${colors.green}✅ Cargo "${roleName}" criado com sucesso!${colors.reset}`);
                    setTimeout(() => {}, 1500);
                });
            });
        });
    });
}

async function listRoles(chatId) {
    clear(); header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                       LISTAR CARGOS                             │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    const roles = loadRoles(chatId);
    
    if (Object.keys(roles.cargos_personalizados || {}).length === 0) {
        console.log(`${colors.yellow}⚠️ Nenhum cargo criado ainda!${colors.reset}`);
    } else {
        for (const [name, data] of Object.entries(roles.cargos_personalizados)) {
            console.log(`${colors.magenta}📌 ${name}${colors.reset}`);
            console.log(`${colors.cyan}   Cor: ${data.cor}${colors.reset}`);
            console.log(`${colors.cyan}   Membros: ${data.membros?.length || 0}${colors.reset}`);
            console.log(`${colors.cyan}   Permissões: ${data.permissoes?.join(', ') || 'nenhuma'}${colors.reset}`);
            console.log();
        }
    }
    
    await new Promise(resolve => {
        rl.question(`${colors.yellow}Pressione ENTER para continuar...${colors.reset}`, resolve);
    });
}

// ==================== COMPONENTES ====================
function getActiveComponents() {
    try {
        if (fs.existsSync(CONFIG.activeFile)) {
            return JSON.parse(fs.readFileSync(CONFIG.activeFile, 'utf8')).components || [];
        }
    } catch(e) {}
    return [];
}

function saveActiveComponent(name) {
    let active = { components: [] };
    try {
        if (fs.existsSync(CONFIG.activeFile)) {
            active = JSON.parse(fs.readFileSync(CONFIG.activeFile, 'utf8'));
        }
    } catch(e) {}
    if (!active.components.includes(name)) active.components.push(name);
    fs.writeFileSync(CONFIG.activeFile, JSON.stringify(active, null, 2));
}

function removeActiveComponent(name) {
    try {
        if (fs.existsSync(CONFIG.activeFile)) {
            let active = JSON.parse(fs.readFileSync(CONFIG.activeFile, 'utf8'));
            active.components = active.components.filter(c => c !== name);
            fs.writeFileSync(CONFIG.activeFile, JSON.stringify(active, null, 2));
        }
    } catch(e) {}
}

async function listComponents() {
    clear(); header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                       COMPONENTES                              │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    
    if (!fs.existsSync(CONFIG.componentsDir)) fs.mkdirSync(CONFIG.componentsDir, { recursive: true });
    const files = fs.readdirSync(CONFIG.componentsDir).filter(f => f.endsWith('.js'));
    const active = getActiveComponents();
    
    if (files.length === 0) {
        console.log(`${colors.yellow}⚠️ Nenhum componente encontrado!${colors.reset}`);
        console.log(`${colors.cyan}💡 Use a opção "Criar Componente" para criar um${colors.reset}`);
    } else {
        files.forEach((file, index) => {
            const status = active.includes(file) ? `${colors.green}[● ATIVO]${colors.reset}` : `${colors.red}[○ INATIVO]${colors.reset}`;
            console.log(`${colors.cyan}${index + 1}.${colors.reset} ${colors.bright}${file}${colors.reset} ${status}`);
        });
    }
    
    console.log(`\n${colors.yellow}─────────────────────────────────────────────────────────────────${colors.reset}`);
    console.log(`${colors.cyan}1.${colors.reset} Ativar componente`);
    console.log(`${colors.cyan}2.${colors.reset} Desativar componente`);
    console.log(`${colors.cyan}3.${colors.reset} Criar componente`);
    console.log(`${colors.cyan}4.${colors.reset} Editar componente`);
    console.log(`${colors.cyan}5.${colors.reset} Voltar`);
    console.log();
    
    rl.question(`${colors.yellow}👉 Escolha uma opção: ${colors.reset}`, async (opt) => {
        if (opt === '1') {
            rl.question(`${colors.yellow}📝 Nome do componente: ${colors.reset}`, n => {
                if (n && files.includes(n)) { saveActiveComponent(n); console.log(`${colors.green}✅ Ativado!${colors.reset}`); }
                else console.log(`${colors.red}❌ Não encontrado${colors.reset}`);
                setTimeout(() => listComponents(), 1500);
            });
        } else if (opt === '2') {
            rl.question(`${colors.yellow}📝 Nome do componente: ${colors.reset}`, n => {
                if (n) { removeActiveComponent(n); console.log(`${colors.green}✅ Desativado!${colors.reset}`); }
                else console.log(`${colors.red}❌ Inválido${colors.reset}`);
                setTimeout(() => listComponents(), 1500);
            });
        } else if (opt === '3') {
            createComponent();
        } else if (opt === '4') {
            rl.question(`${colors.yellow}📝 Nome do componente para editar: ${colors.reset}`, n => {
                if (n && files.includes(n)) editComponent(n);
                else { console.log(`${colors.red}❌ Não encontrado${colors.reset}`); setTimeout(() => listComponents(), 1500); }
            });
        }
    });
}

function createComponent() {
    clear(); header();
    console.log(`${colors.cyan}┌─────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(`${colors.cyan}│                     CRIAR COMPONENTE                          │${colors.reset}`);
    console.log(`${colors.cyan}└─────────────────────────────────────────────────────────────────┘${colors.reset}`);
    console.log();
    console.log(`${colors.yellow}📝 Template do componente:${colors.reset}`);
    console.log(`${colors.green}module.exports = {`);
    console.log(`  name: "Meu Componente",`);
    console.log(`  version: "1.0.0",`);
    console.log(`  description: "Descrição do componente",`);
    console.log(`  onMessage: async (message, sendMessage, sendMedia, hasPermission) => {`);
    console.log(`    const text = message.text?.toLowerCase() || '';`);
    console.log(`    if (text === 'oi') {`);
    console.log(`      await sendMessage(\`Olá \${message.senderName}!\`);`);
    console.log(`    }`);
    console.log(`  },`);
    console.log(`  onStart: async (sendMessage) => {`);
    console.log(`    console.log("✅ Componente iniciado!");`);
    console.log(`  }`);
    console.log(`};${colors.reset}`);
    console.log();
    
    rl.question(`${colors.yellow}📝 Nome do arquivo (ex: meu_componente.js): ${colors.reset}`, (filename) => {
        if (!filename.endsWith('.js')) filename += '.js';
        
        console.log();
        console.log(`${colors.cyan}📝 Digite o código (digite 'FIM' em uma linha vazia para finalizar):${colors.reset}`);
        console.log(`${colors.yellow}─────────────────────────────────────────────────────────────────${colors.reset}`);
        
        let codeLines = [];
        const inputRl = readline.createInterface({ input: process.stdin, output: process.stdout });
        
        const promptCode = () => {
            inputRl.question('', (line) => {
                if (line.trim() === 'FIM') {
                    const code = codeLines.join('\n');
                    if (code.trim()) {
                        const filepath = path.join(CONFIG.componentsDir, filename);
                        fs.writeFileSync(filepath, code);
                        console.log(`${colors.green}✅ Componente criado: ${filename}${colors.reset}`);
                    } else {
                        console.log(`${colors.red}❌ Código vazio!${colors.reset}`);
                    }
                    inputRl.close();
                    setTimeout(() => listComponents(), 1500);
                } else {
                    codeLines.push(line);
                    promptCode();
                }
            });
        };
        promptCode();
    });
}

function editComponent(filename) {
    const filepath = path.join(CONFIG.componentsDir, filename);
    if (!fs.existsSync(filepath)) {
        console.log(`${colors.red}❌ Arquivo não encontrado!${colors.reset}`);
        setTimeout(() => listComponents(), 1500);
        return;
    }
    
    const existingContent = fs.readFileSync(filepath, 'utf8');
    console.log(`${colors.yellow}Código atual:${colors.reset}`);
    console.log(existingContent);
    console.log(`${colors.yellow}─────────────────────────────────────────────────────────────────${colors.reset}`);
    console.log(`${colors.cyan}Digite o novo código (digite 'FIM' para finalizar):${colors.reset}`);
    
    let codeLines = [];
    const inputRl = readline.createInterface({ input: process.stdin, output: process.stdout });
    
    const promptCode = () => {
        inputRl.question('', (line) => {
            if (line.trim() === 'FIM') {
                const code = codeLines.join('\n');
                if (code.trim()) {
                    fs.writeFileSync(filepath, code);
                    console.log(`${colors.green}✅ Componente editado: ${filename}${colors.reset}`);
                } else {
                    console.log(`${colors.red}❌ Código vazio, mantido original!${colors.reset}`);
                }
                inputRl.close();
                setTimeout(() => listComponents(), 1500);
            } else {
                codeLines.push(line);
                promptCode();
            }
        });
    };
    promptCode();
}

// ==================== ENVIO DE MENSAGENS ====================
async function sendTextMessage(chatId, text) {
    const timestamp = Date.now();
    const messageId = `msg_${timestamp}_${Math.random().toString(36).substr(2, 9)}`;
    
    const messageData = {
        ephemeral: false,
        senderId: botConfig.botId,
        senderName: botConfig.userData.name || 'Bot',
        text: text,
        timestamp: timestamp,
        type: 'text'
    };
    
    await httpsRequest(`${CONFIG.firebaseUrl}/groups/${chatId}/messages/${messageId}.json`, 'PUT', messageData);
    return true;
}

async function sendMediaMessage(chatId, type, fileData, caption = '') {
    const timestamp = Date.now();
    const messageId = `msg_${timestamp}_${Math.random().toString(36).substr(2, 9)}`;
    
    const messageData = {
        ephemeral: false,
        senderId: botConfig.botId,
        senderName: botConfig.userData.name || 'Bot',
        text: caption,
        fileData: fileData,
        timestamp: timestamp,
        type: type
    };
    
    if (type === 'image') messageData.fileName = 'image.jpg';
    if (type === 'audio') messageData.fileName = 'audio.webm';
    if (type === 'video') messageData.fileName = 'video.mp4';
    
    await httpsRequest(`${CONFIG.firebaseUrl}/groups/${chatId}/messages/${messageId}.json`, 'PUT', messageData);
    return true;
}

async function manualSend() {
    clear(); header();
    if (!botConfig) {
        console.log(`${colors.red}❌ Autentique primeiro!${colors.reset}`);
        setTimeout(() => {}, 2000);
        return;
    }
    
    console.log(`${colors.yellow}📋 Chats disponíveis:${colors.reset}`);
    const chats = Object.keys(botConfig.chats);
    chats.forEach((c, i) => console.log(`${colors.cyan}${i+1}.${colors.reset} ${c} - ${botConfig.chats[c].name || 'Sem nome'}`));
    console.log();
    
    rl.question(`${colors.yellow}📝 ID do chat: ${colors.reset}`, async (chatId) => {
        if (!botConfig.chats[chatId]) {
            console.log(`${colors.red}❌ Chat não encontrado!${colors.reset}`);
            setTimeout(() => {}, 1500);
            return;
        }
        
        console.log(`\n${colors.yellow}Tipos:${colors.reset}`);
        console.log(`${colors.cyan}1.${colors.reset} Texto`);
        console.log(`${colors.cyan}2.${colors.reset} Áudio (Base64)`);
        console.log(`${colors.cyan}3.${colors.reset} Imagem (URL)`);
        console.log(`${colors.cyan}4.${colors.reset} Vídeo (URL)`);
        console.log();
        
        rl.question(`${colors.yellow}👉 Tipo: ${colors.reset}`, async (type) => {
            if (type === '1') {
                rl.question(`${colors.yellow}📝 Mensagem: ${colors.reset}`, async (msg) => {
                    await sendTextMessage(chatId, msg);
                    console.log(`${colors.green}✅ Enviada!${colors.reset}`);
                    setTimeout(() => {}, 1500);
                });
            } else if (type === '2') {
                rl.question(`${colors.yellow}📝 Áudio (Base64): ${colors.reset}`, async (data) => {
                    await sendMediaMessage(chatId, 'audio', data);
                    console.log(`${colors.green}✅ Áudio enviado!${colors.reset}`);
                    setTimeout(() => {}, 1500);
                });
            } else if (type === '3') {
                rl.question(`${colors.yellow}📝 URL da imagem: ${colors.reset}`, async (url) => {
                    rl.question(`${colors.yellow}📝 Legenda: ${colors.reset}`, async (caption) => {
                        await sendMediaMessage(chatId, 'image', url, caption);
                        console.log(`${colors.green}✅ Imagem enviada!${colors.reset}`);
                        setTimeout(() => {}, 1500);
                    });
                });
            } else if (type === '4') {
                rl.question(`${colors.yellow}📝 URL do vídeo: ${colors.reset}`, async (url) => {
                    rl.question(`${colors.yellow}📝 Legenda: ${colors.reset}`, async (caption) => {
                        await sendMediaMessage(chatId, 'video', url, caption);
                        console.log(`${colors.green}✅ Vídeo enviado!${colors.reset}`);
                        setTimeout(() => {}, 1500);
                    });
                });
            }
        });
    });
}

// ==================== SERVIDOR DO BOT ====================
async function startServer() {
    if (isServerRunning) {
        console.log(`${colors.yellow}⚠️ Servidor já rodando!${colors.reset}`);
        setTimeout(() => {}, 1500);
        return;
    }
    if (!botConfig) {
        console.log(`${colors.red}❌ Autentique primeiro!${colors.reset}`);
        setTimeout(() => {}, 2000);
        return;
    }
    
    console.log(`${colors.green}🚀 Iniciando servidor...${colors.reset}`);
    
    const serverScript = `
    const https = require('https');
    const fs = require('fs');
    const path = require('path');
    
    const CONFIG = {
        firebaseUrl: '${CONFIG.firebaseUrl}',
        botData: ${JSON.stringify(botConfig)}
    };
    
    function httpsReq(url, method = 'GET', data = null) {
        return new Promise((resolve, reject) => {
            const u = new URL(url);
            const opt = { hostname: u.hostname, path: u.pathname + u.search, method, headers: { 'Content-Type': 'application/json' } };
            const req = https.request(opt, res => { let b = ''; res.on('data', c => b += c); res.on('end', () => { try { resolve(b ? JSON.parse(b) : null); } catch(e) { resolve(b); } }); });
            req.on('error', reject);
            if (data) req.write(JSON.stringify(data));
            req.end();
        });
    }
    
    function loadRoles(chatId) {
        try {
            const f = \`roles_\${chatId}.json\`;
            if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf8'));
        } catch(e) {}
        return { cargos_personalizados: {}, dono: '${botConfig.ownerId}' };
    }
    
    function hasPermission(chatId, memberId, permission) {
        const roles = loadRoles(chatId);
        if (roles.dono === memberId) return true;
        for (const [_, roleData] of Object.entries(roles.cargos_personalizados || {})) {
            if (roleData.membros && roleData.membros.includes(memberId)) {
                if (roleData.permissoes && roleData.permissoes.includes(permission)) return true;
            }
        }
        return false;
    }
    
    async function sendMessage(chatId, text, type = 'text', fileData = null) {
        const ts = Date.now();
        const mid = \`msg_\${ts}_\${Math.random().toString(36).substr(2,9)}\`;
        const data = {
            ephemeral: false,
            senderId: '${botConfig.botId}',
            senderName: '${botConfig.userData.name || 'Bot'}',
            text: text,
            timestamp: ts,
            type: type
        };
        if (fileData) data.fileData = fileData;
        if (type === 'image') data.fileName = 'image.jpg';
        if (type === 'audio') data.fileName = 'audio.webm';
        if (type === 'video') data.fileName = 'video.mp4';
        await httpsReq(\`\${CONFIG.firebaseUrl}/groups/\${chatId}/messages/\${mid}.json\`, 'PUT', data);
    }
    
    async function checkMessages() {
        for (const [chatId] of Object.entries(CONFIG.botData.chats || {})) {
            try {
                const msgs = await httpsReq(\`\${CONFIG.firebaseUrl}/groups/\${chatId}/messages.json\`);
                if (msgs) {
                    const last = CONFIG.botData.lastChecked[chatId] || 0;
                    for (const [id, msg] of Object.entries(msgs)) {
                        if (msg.timestamp > last && msg.senderId !== '${botConfig.botId}') {
                            console.log(\`💬 [\${chatId}] \${msg.senderName}: \${msg.text || msg.type}\`);
                            
                            const send = (t, ty = 'text', fd = null) => sendMessage(chatId, t, ty, fd);
                            const hasPerm = (perm) => hasPermission(chatId, msg.senderId, perm);
                            
                            // Comandos básicos integrados
                            const text = msg.text?.toLowerCase() || '';
                            if (text === '/cargos' && hasPerm('gerenciar_cargos')) {
                                const roles = loadRoles(chatId);
                                const lista = Object.keys(roles.cargos_personalizados || {}).join(', ');
                                await send(\`📋 Cargos disponíveis: \${lista || 'Nenhum'}\`);
                            }
                            
                            // Carrega componentes
                            const activeFile = '${CONFIG.activeFile}';
                            const compDir = '${CONFIG.componentsDir}';
                            if (fs.existsSync(activeFile)) {
                                const active = JSON.parse(fs.readFileSync(activeFile, 'utf8'));
                                for (const comp of active.components || []) {
                                    const p = path.join(compDir, comp);
                                    if (fs.existsSync(p)) {
                                        try {
                                            delete require.cache[require.resolve(p)];
                                            const c = require(p);
                                            if (c.onMessage) await c.onMessage(msg, send, null, hasPerm);
                                        } catch(e) { console.log(\`Erro: \${e.message}\`); }
                                    }
                                }
                            }
                        }
                    }
                    CONFIG.botData.lastChecked[chatId] = Date.now();
                    fs.writeFileSync('${CONFIG.dataFile}', JSON.stringify(CONFIG.botData, null, 2));
                }
            } catch(e) { console.log(e.message); }
        }
    }
    
    async function startComponents() {
        const activeFile = '${CONFIG.activeFile}';
        const compDir = '${CONFIG.componentsDir}';
        if (fs.existsSync(activeFile)) {
            const active = JSON.parse(fs.readFileSync(activeFile, 'utf8'));
            for (const comp of active.components || []) {
                const p = path.join(compDir, comp);
                if (fs.existsSync(p)) {
                    try {
                        delete require.cache[require.resolve(p)];
                        const c = require(p);
                        if (c.onStart) await c.onStart(async (t) => console.log(\`Componente: \${t}\`));
                        console.log(\`✅ \${c.name || comp} carregado\`);
                    } catch(e) { console.log(\`Erro: \${e.message}\`); }
                }
            }
        }
    }
    
    startComponents();
    setInterval(checkMessages, 5000);
    console.log('✅ Servidor rodando!');
    `;
    
    const tempFile = 'temp_server.js';
    fs.writeFileSync(tempFile, serverScript);
    serverProcess = spawn('node', [tempFile], { stdio: 'inherit' });
    isServerRunning = true;
    
    serverProcess.on('exit', () => {
        isServerRunning = false;
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
    });
    
    console.log(`${colors.green}✅ Servidor iniciado! Pressione ENTER para voltar${colors.reset}`);
    await new Promise(resolve => { process.stdin.setRawMode(true); process.stdin.resume(); process.stdin.once('data', () => { process.stdin.setRawMode(false); resolve(); }); });
}

function stopServer() {
    if (serverProcess) {
        serverProcess.kill();
        serverProcess = null;
        isServerRunning = false;
        console.log(`${colors.green}✅ Servidor parado!${colors.reset}`);
    } else {
        console.log(`${colors.yellow}⚠️ Nenhum servidor rodando${colors.reset}`);
    }
    setTimeout(() => {}, 1500);
}

// ==================== STATUS ====================
async function showStatus() {
    clear(); header();
    if (botConfig) {
        console.log(`${colors.green}✅ BOT AUTENTICADO${colors.reset}`);
        console.log(`${colors.cyan}ID:${colors.reset} ${botConfig.botId}`);
        console.log(`${colors.cyan}Nome:${colors.reset} ${botConfig.userData.name || 'N/A'}`);
        console.log(`${colors.cyan}Username:${colors.reset} ${botConfig.username || 'N/A'}`);
        console.log(`${colors.cyan}Dono:${colors.reset} ${botConfig.ownerId || 'N/A'}`);
        console.log(`${colors.cyan}Criado em:${colors.reset} ${new Date(botConfig.createdAt).toLocaleString()}`);
        console.log(`${colors.cyan}Chats:${colors.reset} ${Object.keys(botConfig.chats).length}`);
        console.log(`${colors.cyan}Comunidades:${colors.reset} ${Object.keys(botConfig.communities || {}).length}`);
        console.log(`\n${colors.magenta}📦 Componentes ativos:${colors.reset}`);
        const active = getActiveComponents();
        if (active.length === 0) console.log(`  ${colors.yellow}Nenhum${colors.reset}`);
        else active.forEach(c => console.log(`  ${colors.green}✓${colors.reset} ${c}`));
        console.log(`\n${colors.magenta}🖥️ Servidor:${colors.reset} ${isServerRunning ? `${colors.green}ONLINE` : `${colors.red}OFFLINE`}`);
    } else {
        console.log(`${colors.red}❌ BOT NÃO AUTENTICADO${colors.reset}`);
    }
    await new Promise(resolve => rl.question(`\n${colors.yellow}Pressione ENTER${colors.reset}`, resolve));
}

// ==================== MENU PRINCIPAL ====================
async function main() {
    while (true) {
        clear(); header();
        console.log(botConfig ? `${colors.green}✅ Bot: ${botConfig.userData.name}${colors.reset}` : `${colors.red}❌ Não autenticado${colors.reset}`);
        console.log(isServerRunning ? `${colors.green}🟢 Servidor: ONLINE${colors.reset}` : `${colors.red}🔴 Servidor: OFFLINE${colors.reset}`);
        console.log(`\n${colors.cyan}═══════════════════════════════════════════════════════════════${colors.reset}`);
        console.log(`${colors.cyan}1.${colors.reset} 🔐 Autenticar Bot`);
        console.log(`${colors.cyan}2.${colors.reset} 🚀 Iniciar Servidor`);
        console.log(`${colors.cyan}3.${colors.reset} ⏹️  Parar Servidor`);
        console.log(`${colors.cyan}4.${colors.reset} 📨 Enviar Mensagem`);
        console.log(`${colors.cyan}5.${colors.reset} 📦 Gerenciar Componentes`);
        console.log(`${colors.cyan}6.${colors.reset} 👥 Gerenciar Cargos`);
        console.log(`${colors.cyan}7.${colors.reset} ℹ️  Status`);
        console.log(`${colors.cyan}8.${colors.reset} 🚪 Sair`);
        console.log(`${colors.cyan}═══════════════════════════════════════════════════════════════${colors.reset}`);
        
        const opt = await new Promise(res => rl.question(`\n${colors.yellow}👉 Opção: ${colors.reset}`, res));
        
        if (opt === '1') await authBot();
        else if (opt === '2') await startServer();
        else if (opt === '3') stopServer();
        else if (opt === '4') await manualSend();
        else if (opt === '5') await listComponents();
        else if (opt === '6') {
            if (!botConfig) { console.log(`${colors.red}❌ Autentique primeiro!${colors.reset}`); setTimeout(() => {}, 1500); continue; }
            console.log(`\n${colors.yellow}1. Criar cargo\n2. Listar cargos`);
            const sub = await new Promise(res => rl.question(`${colors.yellow}👉 Opção: ${colors.reset}`, res));
            const chatId = Object.keys(botConfig.chats)[0];
            if (sub === '1') await createRole(chatId);
            else if (sub === '2') await listRoles(chatId);
        }
        else if (opt === '7') await showStatus();
        else if (opt === '8') {
            if (serverProcess) serverProcess.kill();
            console.log(`${colors.green}👋 Até logo!${colors.reset}`);
            rl.close();
            process.exit(0);
        }
    }
}

console.log(`${colors.green}🚀 Iniciando BOT SYSTEM...${colors.reset}`);
main();